import java.io.IOException;

public class Main {

    public static void main (String [] argument) throws IOException {

        MenuGeneral menu = new MenuGeneral();
        menu.afficherMenu();
    }
}
