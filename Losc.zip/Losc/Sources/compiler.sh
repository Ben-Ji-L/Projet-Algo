#!/bin/bash

javac Main.java MenuGeneral.java MenuLocataires.java Locataire.java ListeLocataires.java MenuBiens.java Bien.java ListeBiens.java MenuTypesDeBiens.java TypeDeBien.java ListeTypesDeBiens.java MenuLocations.java
